package com.app.springboot.employee;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class EmployeeService {
	
	@Autowired
	private EmployeeRepository employeeRepository;
	
	public void saveEmployee(Employee employee) {
		employeeRepository.save(employee);
	}
	public Employee findEmployee(int empId) {
		return employeeRepository.findOne(empId);
	}
	public Iterable<Employee> findAllEmployees() {
		return employeeRepository.findAll();
	}
	public void deleteUser(int empId) {
		employeeRepository.delete(empId);		
	}
	

	


}
