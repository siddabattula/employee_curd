package com.app.springboot.employee.unittest;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import org.hamcrest.Matchers;
import org.junit.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.servlet.MockMvc;

import com.app.springboot.employee.Employee;
import com.app.springboot.employee.EmployeeRepository;
import com.app.springboot.employee.EmployeeService;


@WebMvcTest
public class EmployeeControllerTest {
	
	@MockBean
	EmployeeService employeeService;
	
	@Autowired
    private MockMvc mockMvc;
	
	/*
	 * @Test public void saveEmployeeTest() throws Exception { Employee employee =
	 * new Employee(100,"jani","thousands");
	 * Mockito.when(employeeService.saveEmployee("employee"));
	 * mockMvc.perform(post("/postMapping") .andExpect("id", Matchers.equalTo(1)))
	 * .andExpect("name", Matchers.equalTo("jani")); }
	 * 
	 * @Test public void getEmployeeTest() throws Exception { Employee employee =
	 * new Employee(100,"jani","thousands");
	 * Mockito.when(employeeService.find("employeeName")).thenReturn("employeeName")
	 * ; mockMvc.perform(get("/getMapping")) .andExpect("name",
	 * Matchers.equalTo("jani"));
	 * 
	 * }
	 */
	

}
